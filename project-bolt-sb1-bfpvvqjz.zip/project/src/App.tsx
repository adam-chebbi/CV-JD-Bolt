import React, { useState, useCallback, useEffect } from 'react';
import { FileUpload } from './components/FileUpload';
import { ResultsChart } from './components/ResultsChart';
import { MatchingVisual } from './components/MatchingVisual';
import { FileText, Briefcase, Trash2, AlertCircle } from 'lucide-react';
import {
  preprocessText,
  calculateTFIDF,
  calculateSimilarity,
  analyzeKeywords
} from './utils/textProcessing';
import { initDB, storeFile, getFiles, deleteFile } from './utils/storage';
import * as pdfjsLib from 'pdfjs-dist';
import { Toast } from './components/Toast';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface MatchResult {
  name: string;
  score: number;
  keywordMatches: Array<{ keyword: string; frequency: number; relevance: number }>;
}

interface ToastMessage {
  type: 'success' | 'error' | 'info';
  message: string;
}

function App() {
  const [cvs, setCvs] = useState<{ id: string; name: string; content: string }[]>([]);
  const [jd, setJd] = useState<string>('');
  const [jdText, setJdText] = useState<string>('');
  const [useTextInput, setUseTextInput] = useState(false);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedCV, setSelectedCV] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    const loadStoredFiles = async () => {
      try {
        await initDB();
        const storedCVs = await getFiles('cv');
        setCvs(storedCVs.map(file => ({
          id: file.id,
          name: file.name,
          content: file.content
        })));
        
        const storedJDs = await getFiles('jd');
        if (storedJDs.length > 0) {
          const latestJD = storedJDs.sort((a, b) => b.timestamp - a.timestamp)[0];
          setJd(latestJD.content);
        }
      } catch (error) {
        setToast({
          type: 'error',
          message: 'Failed to load saved files. Please try refreshing the page.'
        });
      } finally {
        setIsInitializing(false);
      }
    };
    
    loadStoredFiles();
  }, []);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 5000);
  };

  const extractTextFromPDF = async (file: File): Promise<string> => {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map((item: any) => item.str).join(' ');
        fullText += pageText + ' ';
      }
      
      if (!fullText.trim()) {
        throw new Error('No text could be extracted from the PDF');
      }
      
      return fullText;
    } catch (error) {
      throw new Error('Failed to read PDF file. Please ensure it contains extractable text.');
    }
  };

  const handleCVUpload = useCallback(async (file: File) => {
    try {
      setIsProcessing(true);
      showToast('Processing CV...', 'info');
      
      const text = await extractTextFromPDF(file);
      const id = await storeFile(file.name, text, 'cv');
      setCvs(prev => [...prev, { id, name: file.name, content: text }]);
      
      const activeJD = useTextInput ? jdText : jd;
      if (activeJD) {
        const keywordMatches = analyzeKeywords(text, activeJD);
        const processedJD = preprocessText(activeJD);
        const processedCV = preprocessText(text);
        const jdVector = calculateTFIDF(processedJD, [processedJD, processedCV]);
        const cvVector = calculateTFIDF(processedCV, [processedJD, processedCV]);
        const similarity = calculateSimilarity(jdVector, cvVector);
        
        setResults(prev => [...prev, {
          name: file.name,
          score: similarity,
          keywordMatches
        }].sort((a, b) => b.score - a.score));
      }
      
      showToast('CV uploaded successfully!', 'success');
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Failed to process CV', 'error');
    } finally {
      setIsProcessing(false);
    }
  }, [jd, jdText, useTextInput]);

  const handleJDUpload = useCallback(async (file: File) => {
    try {
      setIsProcessing(true);
      showToast('Processing Job Description...', 'info');
      
      const text = await extractTextFromPDF(file);
      await storeFile(file.name, text, 'jd');
      setJd(text);
      setUseTextInput(false);
      
      if (cvs.length > 0) {
        const newResults = cvs.map(cv => {
          const keywordMatches = analyzeKeywords(cv.content, text);
          const processedJD = preprocessText(text);
          const processedCV = preprocessText(cv.content);
          const jdVector = calculateTFIDF(processedJD, [processedJD, processedCV]);
          const cvVector = calculateTFIDF(processedCV, [processedJD, processedCV]);
          const similarity = calculateSimilarity(jdVector, cvVector);
          
          return {
            name: cv.name,
            score: similarity,
            keywordMatches
          };
        });
        
        setResults(newResults.sort((a, b) => b.score - a.score));
      }
      
      showToast('Job Description uploaded successfully!', 'success');
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'Failed to process Job Description', 'error');
    } finally {
      setIsProcessing(false);
    }
  }, [cvs]);

  const handleJDTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setJdText(text);
    setUseTextInput(true);
    
    if (text.trim()) {
      storeFile('Manual JD Entry', text, 'jd');
      
      if (cvs.length > 0) {
        const newResults = cvs.map(cv => {
          const keywordMatches = analyzeKeywords(cv.content, text);
          const processedJD = preprocessText(text);
          const processedCV = preprocessText(cv.content);
          const jdVector = calculateTFIDF(processedJD, [processedJD, processedCV]);
          const cvVector = calculateTFIDF(processedCV, [processedJD, processedCV]);
          const similarity = calculateSimilarity(jdVector, cvVector);
          
          return {
            name: cv.name,
            score: similarity,
            keywordMatches
          };
        });
        
        setResults(newResults.sort((a, b) => b.score - a.score));
      }
    }
  };

  const handleDeleteCV = async (id: string) => {
    try {
      await deleteFile(id);
      setCvs(prev => prev.filter(cv => cv.id !== id));
      setResults(prev => prev.filter(result => 
        !cvs.find(cv => cv.id === id && cv.name === result.name)
      ));
      if (selectedCV === id) {
        setSelectedCV(null);
      }
      showToast('CV deleted successfully', 'success');
    } catch (error) {
      showToast('Failed to delete CV', 'error');
    }
  };

  const calculateMatches = useCallback(() => {
    try {
      const activeJD = useTextInput ? jdText : jd;
      if (!activeJD || cvs.length === 0) {
        showToast('Please upload both CVs and a Job Description', 'error');
        return;
      }

      const newResults = cvs.map(cv => {
        const keywordMatches = analyzeKeywords(cv.content, activeJD);
        const processedJD = preprocessText(activeJD);
        const processedCV = preprocessText(cv.content);
        const jdVector = calculateTFIDF(processedJD, [processedJD, processedCV]);
        const cvVector = calculateTFIDF(processedCV, [processedJD, processedCV]);
        const similarity = calculateSimilarity(jdVector, cvVector);
        
        return {
          name: cv.name,
          score: similarity,
          keywordMatches
        };
      });

      setResults(newResults.sort((a, b) => b.score - a.score));
      showToast('Matches recalculated successfully', 'success');
    } catch (error) {
      showToast('Failed to calculate matches', 'error');
    }
  }, [jd, jdText, useTextInput, cvs]);

  const selectedResult = selectedCV 
    ? results.find(r => cvs.find(cv => cv.id === selectedCV && cv.name === r.name))
    : null;

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Initializing application...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">CV-JD Matcher</h1>
          <p className="mt-2 text-gray-600">Upload CVs and a Job Description to find the best matches</p>
        </div>

        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5" />
              CVs ({cvs.length})
            </h2>
            <FileUpload
              onFileSelect={handleCVUpload}
              accept={{ 'application/pdf': ['.pdf'] }}
              label="Drop CV files here or click to upload"
              isProcessing={isProcessing}
            />
            {cvs.length === 0 && !isProcessing && (
              <div className="bg-blue-50 p-4 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  Start by uploading one or more CVs in PDF format. The text will be extracted automatically.
                </p>
              </div>
            )}
            {cvs.length > 0 && (
              <ul className="space-y-2">
                {cvs.map((cv) => {
                  const result = results.find(r => r.name === cv.name);
                  return (
                    <li 
                      key={cv.id} 
                      className={`flex items-center justify-between text-sm bg-white p-2 rounded-lg cursor-pointer transition-colors ${
                        selectedCV === cv.id ? 'ring-2 ring-blue-500' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedCV(selectedCV === cv.id ? null : cv.id)}
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <span className="text-gray-600">{cv.name}</span>
                        {result && (
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            result.score >= 0.7 ? 'bg-green-100 text-green-800' :
                            result.score >= 0.5 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {(result.score * 100).toFixed(1)}%
                          </span>
                        )}
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteCV(cv.id);
                        }}
                        className="text-red-500 hover:text-red-700 p-1"
                        title="Delete CV"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Briefcase className="w-5 h-5" />
              Job Description
            </h2>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Enter Job Description Text
                </label>
                <textarea
                  value={jdText}
                  onChange={handleJDTextChange}
                  className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Paste your job description here..."
                />
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-gray-50 text-gray-500">OR</span>
                </div>
              </div>

              <FileUpload
                onFileSelect={handleJDUpload}
                accept={{ 'application/pdf': ['.pdf'] }}
                label="Drop JD file here or click to upload"
                isProcessing={isProcessing}
              />
            </div>

            {!jd && !jdText && !isProcessing && (
              <div className="bg-blue-50 p-4 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-700">
                  Add a job description by either pasting the text above or uploading a PDF file.
                </p>
              </div>
            )}

            {jd && !useTextInput && (
              <p className="text-sm text-gray-600">JD file uploaded and processed</p>
            )}
          </div>
        </div>

        {isProcessing ? (
          <div className="text-center space-y-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
            <p className="text-gray-600">Processing files...</p>
          </div>
        ) : (
          <>
            {cvs.length > 0 && (useTextInput ? jdText : jd) && (
              <button
                onClick={calculateMatches}
                className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Recalculate All Matches
              </button>
            )}

            {selectedResult && (
              <MatchingVisual
                keywordMatches={selectedResult.keywordMatches}
                overallScore={selectedResult.score}
              />
            )}

            {results.length > 0 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold">Overall Results</h2>
                <ResultsChart data={results} />
                
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          CV Name
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Match Score
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {results.map((result, index) => (
                        <tr 
                          key={index}
                          className={`hover:bg-gray-50 cursor-pointer ${
                            selectedCV === cvs.find(cv => cv.name === result.name)?.id
                              ? 'bg-blue-50'
                              : ''
                          }`}
                          onClick={() => {
                            const cv = cvs.find(cv => cv.name === result.name);
                            if (cv) {
                              setSelectedCV(selectedCV === cv.id ? null : cv.id);
                            }
                          }}
                        >
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {result.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            <span className={`px-2 py-1 rounded-full font-medium ${
                              result.score >= 0.7 ? 'bg-green-100 text-green-800' :
                              result.score >= 0.5 ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {(result.score * 100).toFixed(2)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;