import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface KeywordMatch {
  keyword: string;
  frequency: number;
  relevance: number;
}

interface MatchingVisualProps {
  keywordMatches: KeywordMatch[];
  overallScore: number;
}

export const MatchingVisual: React.FC<MatchingVisualProps> = ({ keywordMatches, overallScore }) => {
  const sortedMatches = [...keywordMatches]
    .sort((a, b) => b.relevance - a.relevance)
    .slice(0, 10);

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Matching Analysis</h3>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-600">Overall Match:</span>
          <span className={`text-lg font-bold ${
            overallScore >= 0.7 ? 'text-green-600' :
            overallScore >= 0.5 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {(overallScore * 100).toFixed(1)}%
          </span>
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={sortedMatches} layout="vertical" margin={{ left: 100 }}>
            <XAxis type="number" domain={[0, 1]} />
            <YAxis dataKey="keyword" type="category" />
            <Tooltip
              formatter={(value: number) => `${(value * 100).toFixed(1)}%`}
              labelStyle={{ color: '#374151' }}
            />
            <Bar dataKey="relevance" fill="#3b82f6">
              {sortedMatches.map((entry, index) => (
                <Cell
                  key={index}
                  fill={entry.relevance >= 0.7 ? '#059669' :
                        entry.relevance >= 0.5 ? '#D97706' :
                        '#DC2626'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}