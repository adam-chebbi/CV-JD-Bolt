import { openDB, IDBPDatabase } from 'idb';

interface StoredFile {
  id: string;
  name: string;
  content: string;
  type: 'cv' | 'jd';
  timestamp: number;
}

const DB_NAME = 'cv-matcher-db';
const STORE_NAME = 'files';

let db: IDBPDatabase | null = null;

export const initDB = async () => {
  if (!db) {
    db = await openDB(DB_NAME, 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('type', 'type');
          store.createIndex('timestamp', 'timestamp');
        }
      },
    });
  }
  return db;
};

export const storeFile = async (
  name: string,
  content: string,
  type: 'cv' | 'jd'
): Promise<string> => {
  const db = await initDB();
  const id = crypto.randomUUID();
  const file: StoredFile = {
    id,
    name,
    content,
    type,
    timestamp: Date.now(),
  };
  await db.put(STORE_NAME, file);
  return id;
};

export const getFiles = async (type: 'cv' | 'jd'): Promise<StoredFile[]> => {
  const db = await initDB();
  const tx = db.transaction(STORE_NAME, 'readonly');
  const index = tx.store.index('type');
  return index.getAll(type);
};

export const deleteFile = async (id: string): Promise<void> => {
  const db = await initDB();
  await db.delete(STORE_NAME, id);
};