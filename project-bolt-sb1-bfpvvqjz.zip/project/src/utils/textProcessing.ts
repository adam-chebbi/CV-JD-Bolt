// Simple text preprocessing
export const preprocessText = (text: string): string[] => {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 2);
};

// Calculate TF-IDF
export const calculateTFIDF = (doc: string[], docs: string[][]): Map<string, number> => {
  const tf = new Map<string, number>();
  const tfidf = new Map<string, number>();
  
  // Calculate term frequency
  doc.forEach(term => {
    tf.set(term, (tf.get(term) || 0) + 1);
  });
  
  // Calculate IDF and TF-IDF
  tf.forEach((freq, term) => {
    const docsWithTerm = docs.filter(d => d.includes(term)).length;
    const idf = Math.log(docs.length / (docsWithTerm || 1));
    tfidf.set(term, freq * idf);
  });
  
  return tfidf;
};

// Calculate cosine similarity
export const calculateSimilarity = (vec1: Map<string, number>, vec2: Map<string, number>): number => {
  let dotProduct = 0;
  let norm1 = 0;
  let norm2 = 0;
  
  // Calculate dot product and norms
  vec1.forEach((val1, key) => {
    const val2 = vec2.get(key) || 0;
    dotProduct += val1 * val2;
    norm1 += val1 * val1;
  });
  
  vec2.forEach(val2 => {
    norm2 += val2 * val2;
  });
  
  return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
};

// Extract key terms and their relevance
export const analyzeKeywords = (
  cvText: string,
  jdText: string
): { keyword: string; frequency: number; relevance: number }[] => {
  const cvWords = preprocessText(cvText);
  const jdWords = preprocessText(jdText);
  
  // Get word frequencies
  const cvFreq = new Map<string, number>();
  const jdFreq = new Map<string, number>();
  
  cvWords.forEach(word => {
    cvFreq.set(word, (cvFreq.get(word) || 0) + 1);
  });
  
  jdWords.forEach(word => {
    jdFreq.set(word, (jdFreq.get(word) || 0) + 1);
  });
  
  // Calculate relevance scores
  const keywords = new Set([...cvWords, ...jdWords]);
  const results: { keyword: string; frequency: number; relevance: number }[] = [];
  
  keywords.forEach(keyword => {
    const cvCount = cvFreq.get(keyword) || 0;
    const jdCount = jdFreq.get(keyword) || 0;
    
    if (jdCount > 0) { // Only include terms that appear in the job description
      const frequency = cvCount;
      const relevance = (cvCount > 0 ? 1 : 0) * (jdCount / jdWords.length);
      
      results.push({
        keyword,
        frequency,
        relevance
      });
    }
  });
  
  return results;
};